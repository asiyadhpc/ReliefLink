const K = { session: "rl_session" };

// ========================================
// SESSION AND HELPERS
// ========================================
function getSession() {
    try {
        return JSON.parse(localStorage.getItem(K.session));
    } catch {
        return null;
    }
}

function saveSession(session) {
    localStorage.setItem(K.session, JSON.stringify(session));
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}

// Formats GPS coordinates into a clickable Google Maps link
function formatLocationDisplay(locationStr) {
    const raw = String(locationStr || "").trim();
    if (!raw) return "Location not specified";

    const coordMatch = raw.match(/-?\d{1,3}\.\d+,\s*-?\d{1,3}\.\d+/);
    if (coordMatch) {
        const coords = coordMatch[0];
        const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(coords)}`;
        return `<a href="${mapsUrl}" target="_blank" rel="noopener noreferrer" style="color:#087e78;font-weight:700;text-decoration:underline;">📍 Open in Maps (${escapeHTML(coords)})</a>`;
    }

    return escapeHTML(raw);
}

function getDescription(request) {
    return request.description || request.details || "No description provided";
}

function statusPill(status) {
    const classes = {
        Resolved: "resolved",
        Approved: "resolved",
        "In Progress": "progress",
        Scheduled: "progress",
        Rejected: "rejected",
        Pending: "pending",
        Available: "pending"
    };

    return `<span class="pill ${classes[status] || "pending"}">${escapeHTML(status || "Pending")}</span>`;
}

function priorityPill(priority) {
    const classes = {
        Low: "low",
        Medium: "medium",
        High: "high"
    };

    return `<span class="pill ${classes[priority] || "medium"}">${escapeHTML(priority || "Medium")}</span>`;
}

function normalizeRole(value) {
    const role = String(value || "").trim().toLowerCase();

    if (["user", "community user", "community-user", "community_user"].includes(role)) return "user";
    if (["volunteer", "community volunteer"].includes(role)) return "volunteer";
    if (["admin", "administrator"].includes(role)) return "admin";

    return "";
}

function normalizeList(data, keys = []) {
    if (Array.isArray(data)) return data;

    for (const key of keys) {
        if (Array.isArray(data?.[key])) return data[key];
    }

    return [];
}

function setText(id, value) {
    const element = document.getElementById(id);
    if (element) element.textContent = String(value ?? "");
}

function showError(error) {
    console.error("ReliefLink error:", error);
    alert(error?.message || "Something went wrong. Please try again.");
}

function go(role) {
    const normalizedRole = normalizeRole(role);

    const pages = {
        user: "user-dashboard.html",
        volunteer: "volunteer-dashboard.html",
        admin: "admin-dashboard.html"
    };

    if (pages[normalizedRole]) {
        window.location.assign(pages[normalizedRole]);
    } else {
        alert("Please select Community User, Volunteer, or Administrator.");
    }
}

// ========================================
// API HELPERS
// ========================================
async function api(url, options = {}) {
    const headers = { ...(options.headers || {}) };
    const isFormData = options.body instanceof FormData;

    if (!isFormData && options.body !== undefined) {
        headers["Content-Type"] = "application/json";
    }

    let response;

    try {
        response = await fetch(url, {
            ...options,
            headers,
            cache: "no-store"
        });
    } catch {
        throw new Error("Cannot connect to Flask. Check that python app.py is running.");
    }

    const text = await response.text();
    let data = {};

    if (text) {
        try {
            data = JSON.parse(text);
        } catch {
            data = { message: text };
        }
    }

    if (!response.ok) {
        throw new Error(
            data.error ||
            data.message ||
            `Request failed with HTTP ${response.status}`
        );
    }

    return data;
}

async function uploadApi(url, formData) {
    return api(url, {
        method: "POST",
        body: formData
    });
}

// ========================================
// LOGIN
// ========================================
function setupLogin() {
    const form = document.getElementById("loginForm");
    if (!form || form.dataset.rlLoginReady === "true") return;
    form.dataset.rlLoginReady = "true";

    form.addEventListener("submit", event => {
        event.preventDefault();

        const role = normalizeRole(document.getElementById("role")?.value);
        const email = document.getElementById("email")?.value.trim();
        const password = document.getElementById("password")?.value;

        if (!role || !email || !password) {
            alert("Please select a role and fill in all login fields.");
            return;
        }

        saveSession({
            role,
            email: email.toLowerCase(),
            name: email.split("@")[0]
        });

        go(role);
    });
}

// ========================================
// VOLUNTEER REGISTRATION
// ========================================
function setupVolunteerRegistration() {
    const form = document.getElementById("volunteerForm");
    if (!form || form.dataset.rlReady === "true") return;
    form.dataset.rlReady = "true";

    form.addEventListener("submit", async event => {
        event.preventDefault();
        const button = form.querySelector('[type="submit"]');

        try {
            if (button) button.disabled = true;

            const name = document.getElementById("vName")?.value.trim();
            const email = document.getElementById("vEmail")?.value.trim();
            const phone = document.getElementById("vPhone")?.value.trim();
            const skill = document.getElementById("vSkill")?.value;

            if (!name || !email || !phone || !skill) {
                throw new Error("Please complete all volunteer registration fields.");
            }

            const result = await api("/api/volunteers", {
                method: "POST",
                body: JSON.stringify({ name, email, phone, skill })
            });

            alert(result.message || "Volunteer application submitted successfully.");
            form.reset();
            window.location.href = "login.html";
        } catch (error) {
            showError(error);
        } finally {
            if (button) button.disabled = false;
        }
    });
}

// ========================================
// LOGOUT AND SESSION CHECK
// ========================================
function setupLogout() {
    document.querySelectorAll("[data-logout]").forEach(button => {
        if (button.dataset.rlReady === "true") return;
        button.dataset.rlReady = "true";

        button.addEventListener("click", () => {
            localStorage.removeItem(K.session);
            window.location.href = "login.html";
        });
    });
}

function requireSession(page) {
    const session = getSession();

    if (!session) {
        window.location.href = "login.html";
        return null;
    }

    session.role = normalizeRole(session.role);

    if (!session.role) {
        localStorage.removeItem(K.session);
        window.location.href = "login.html";
        return null;
    }

    if (session.role !== page) {
        alert("Please sign in with the correct role.");
        go(session.role);
        return null;
    }

    setText("displayName", session.name || page);
    return session;
}

// ========================================
// COMMUNITY ALERTS
// ========================================
function getIncidentImageUrl(incident) {
    const url = incident.image_url || incident.image || incident.image_path || "";
    if (url.startsWith("/") || /^https?:\/\//i.test(url)) {
        return url;
    }
    return "";
}

function renderIncidentCard(incident) {
    const imageUrl = getIncidentImageUrl(incident);
    const category = incident.category || incident.type || "Safety Alert";
    const location = incident.location || "Location not provided";
    const description = incident.description || incident.details || "No description provided";
    const reporter = incident.posted_by || incident.reporter || incident.owner || "Community team";
    const date = incident.created_at || incident.date || "";

    return `
        <article class="incident-card" style="border:1px solid #dce5e9;border-radius:12px;padding:14px;margin:12px 0;background:#fff;">
            <h3>${escapeHTML(category)}</h3>
            <p><strong>Location:</strong> ${formatLocationDisplay(location)}</p>
            <p style="white-space:pre-wrap;">${escapeHTML(description)}</p>
            ${imageUrl ? `<img src="${escapeHTML(imageUrl)}" alt="Alert image" loading="lazy" style="display:block;width:100%;max-width:520px;max-height:320px;object-fit:contain;border-radius:8px;margin-top:10px;">` : ""}
            <p style="color:#657783;font-size:13px;">
                Posted by ${escapeHTML(reporter)} ${date ? " · " + escapeHTML(date) : ""}
            </p>
        </article>
    `;
}

async function loadIncidents() {
    const feed = document.getElementById("alertFeed");
    if (!feed) return;

    feed.textContent = "Loading community alerts...";

    try {
        const data = await api("/api/incidents");
        const incidents = normalizeList(data, ["incidents", "alerts"]);

        feed.innerHTML = incidents.length
            ? incidents.map(renderIncidentCard).join("")
            : "<p>No community alerts have been published yet.</p>";
    } catch (error) {
        console.error("Could not load alerts:", error);
        feed.textContent = "Alerts could not be loaded. Check the Flask /api/incidents endpoint.";
    }
}

function setupIncidentForm(session) {
    const form = document.getElementById("alertForm");
    if (!form || form.dataset.rlReady === "true") return;
    form.dataset.rlReady = "true";

    const message = document.getElementById("alertMessage");

    if (!["admin", "volunteer"].includes(session.role)) {
        form.hidden = true;
        return;
    }

    form.addEventListener("submit", async event => {
        event.preventDefault();
        const button = form.querySelector('[type="submit"]');
        const category = document.getElementById("alertCategory")?.value;
        const location = document.getElementById("alertLocation")?.value.trim();
        const description = document.getElementById("alertDescription")?.value.trim();
        const image = document.getElementById("alertImage")?.files?.[0];

        if (!category || !location || !description) {
            if (message) message.textContent = "Enter the category, location, and description.";
            return;
        }

        if (image && !image.type.startsWith("image/")) {
            if (message) message.textContent = "Please select a valid image file.";
            return;
        }

        // Fixed mathematical syntax check for 5 MB limit
        if (image && image.size > 5 * 1024 * 1024) {
            if (message) message.textContent = "The image must be 5 MB or smaller.";
            return;
        }

        const formData = new FormData();
        formData.append("category", category);
        formData.append("location", location);
        formData.append("description", description);
        formData.append("posted_by", session.email);
        formData.append("role", session.role);

        if (image) formData.append("image", image);

        try {
            if (button) button.disabled = true;
            if (message) message.textContent = "Publishing alert...";

            const result = await uploadApi("/api/incidents", formData);
            if (message) message.textContent = result.message || "Alert published successfully.";

            form.reset();
            await loadIncidents();
        } catch (error) {
            if (message) message.textContent = `Could not publish alert: ${error.message}`;
            console.error(error);
        } finally {
            if (button) button.disabled = false;
        }
    });
}

// ========================================
// SHARED REQUEST LOADER
// ========================================
async function getAllRequests() {
    const data = await api("/api/requests");
    return normalizeList(data, ["requests", "data", "items"]);
}

// ========================================
// VOLUNTEER DONATION MANAGEMENT
// ========================================
async function loadVolunteerDonations(session) {
    const table = document.getElementById("volunteerDonationsTable");
    if (!table) return;

    try {
        const data = await api("/api/donations");
        const list = normalizeList(data, ["donations", "data", "items"]);

        if (!list.length) {
            table.innerHTML = '<tr><td colspan="7">No item donations available at this time.</td></tr>';
            return;
        }

        table.innerHTML = list.map(item => {
            const isScheduled = item.status === "Scheduled";
            return `
                <tr>
                    <td>#D-${escapeHTML(item.id)}</td>
                    <td>
                        <div style="font-weight:700; color:#092d46;">${escapeHTML(item.donor_name)}</div>
                        <a href="mailto:${escapeHTML(item.donor_email)}" style="font-size:11px; color:#087e78; text-decoration:underline;">${escapeHTML(item.donor_email)}</a>
                    </td>
                    <td><span class="pill medium">${escapeHTML(item.item_category)}</span></td>
                    <td>${formatLocationDisplay(item.location)}</td>
                    <td>${escapeHTML(item.item_details)}</td>
                    <td>${statusPill(item.status)}</td>
                    <td>
                        ${isScheduled 
                            ? `<div style="font-size:11px; color:#07866e; font-weight:700;">
                                    ✓ Scheduled: "${escapeHTML(item.pickup_message)}"
                                    <div style="font-size:10px; color:#657783; font-weight:normal; margin-top:2px;">Assigned: ${escapeHTML(item.assigned_volunteer || "Volunteer")}</div>
                               </div>`
                            : `
                                <div style="display:flex; flex-direction:column; gap:6px;">
                                    <input type="text" id="msg-${item.id}" placeholder="e.g. We will pick up today by 4 PM" style="padding:6px; font-size:11px; border:1px solid #dce8f1; border-radius:6px; outline:none;">
                                    <button type="button" class="primary" data-pickup-id="${item.id}" style="padding:6px 10px; font-size:11px;">
                                        🚚 Send Message & Pick Up
                                    </button>
                                </div>
                            `}
                    </td>
                </tr>
            `;
        }).join("");

        table.querySelectorAll("[data-pickup-id]").forEach(btn => {
            btn.addEventListener("click", async () => {
                const id = btn.dataset.pickupId;
                const input = document.getElementById(`msg-${id}`);
                const message = (input?.value || "").trim();

                if (!message) {
                    alert("Please enter a pickup message for the donor (e.g. 'We will pick up today by 4 PM').");
                    return;
                }

                try {
                    btn.disabled = true;
                    btn.textContent = "Sending...";
                    await api(`/api/donations/${id}/schedule`, {
                        method: "PATCH",
                        body: JSON.stringify({
                            volunteer_email: session.email,
                            pickup_message: message
                        })
                    });
                    await loadVolunteerDonations(session);
                } catch (err) {
                    showError(err);
                    btn.disabled = false;
                    btn.textContent = "🚚 Send Message & Pick Up";
                }
            });
        });
    } catch (err) {
        console.error("Could not load donations:", err);
        table.innerHTML = '<tr><td colspan="7">Unable to load item donations. Check the Flask backend.</td></tr>';
    }
}

// ========================================
// VOLUNTEER DASHBOARD
// ========================================
async function setupVolunteerDashboard(session) {
    const table = document.getElementById("volunteerRequestsTable");
    const filter = document.getElementById("statusFilter");

    async function render() {
        const requests = await getAllRequests();
        const selectedStatus = filter?.value || "All";

        const shown = selectedStatus === "All"
            ? requests
            : requests.filter(item => item.status === selectedStatus);

        setText("volOpen", requests.filter(item => (item.status || "Pending") === "Pending").length);
        setText("volProgress", requests.filter(item => item.status === "In Progress").length);
        setText("volCompleted", requests.filter(item => item.status === "Resolved").length);
        setText("volHelped", requests.filter(item => item.status === "Resolved").length);

        if (!table) return;

        table.innerHTML = shown.length
            ? shown.map(item => {
                let volunteerAction = "";

                if (item.offer_status === "Offered") {
                    volunteerAction = `
                        <div style="margin-top:8px;padding:8px;background:#e6f8f5;border:1px solid #99ded7;border-radius:8px;">
                            <strong style="color:#087e78;font-size:11px;display:block;">Helper Waiting for Approval:</strong>
                            <span style="font-size:11px;color:#29445d;">${escapeHTML(item.helper_email)}</span>
                            <div style="margin-top:6px;">
                                <button type="button" class="primary" data-proceed-id="${escapeHTML(item.id)}" style="padding:6px 12px;font-size:11px;border-radius:6px;cursor:pointer;">
                                    ⚡ Proceed (Approve)
                                </button>
                            </div>
                        </div>
                    `;
                } else if ((item.status || "Pending") === "Pending") {
                    volunteerAction = `
                        <div style="margin-top:8px;">
                            <button type="button" class="primary" data-proceed-id="${escapeHTML(item.id)}" style="padding:6px 12px;font-size:11px;border-radius:6px;cursor:pointer;">
                                ⚡ Proceed
                            </button>
                        </div>
                    `;
                } else if (item.status === "In Progress") {
                    volunteerAction = `
                        <div style="margin-top:6px;font-size:11px;color:#087e78;font-weight:600;">
                            ✓ Approved / In Progress
                            <div style="color:#72869b;font-weight:normal;">Waiting for helper/user confirmation...</div>
                        </div>
                    `;
                } else if (item.status === "Resolved") {
                    volunteerAction = `
                        <div style="margin-top:6px;font-size:11px;color:#07866e;font-weight:700;">
                            ✓ User Confirmed Helped
                        </div>
                    `;
                }

                return `
                <tr>
                    <td>#RL-${escapeHTML(item.id)}</td>
                    <td>
                        <div style="font-weight:700; color:#092d46;">${escapeHTML(item.name || "User")}</div>
                        <a href="mailto:${escapeHTML(item.owner || item.email)}" style="font-size:11px; color:#087e78; text-decoration:underline;">${escapeHTML(item.owner || item.email)}</a>
                    </td>
                    <td>${escapeHTML(item.type || item.category)}</td>
                    <td>${formatLocationDisplay(item.location)}</td>
                    <td>${escapeHTML(getDescription(item))}</td>
                    <td>${priorityPill(item.priority)}</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                            ${statusPill(item.status || "Pending")}
                            <select data-request-id="${escapeHTML(item.id)}" aria-label="Update request status" style="padding:4px 8px;border-radius:6px;border:1px solid #d5e0e6;font-size:11px;">
                                <option value="Pending" ${(item.status || "Pending") === "Pending" ? "selected" : ""}>Pending</option>
                                <option value="In Progress" ${item.status === "In Progress" ? "selected" : ""}>In Progress</option>
                                <option value="Resolved" ${item.status === "Resolved" ? "selected" : ""}>Resolved</option>
                            </select>
                        </div>
                        ${volunteerAction}
                    </td>
                </tr>
            `;
            }).join("")
            : '<tr><td colspan="7">No matching requests.</td></tr>';

        table.querySelectorAll("[data-request-id]").forEach(select => {
            select.addEventListener("change", async () => {
                try {
                    select.disabled = true;
                    await api(`/api/requests/${select.dataset.requestId}`, {
                        method: "PATCH",
                        body: JSON.stringify({ status: select.value })
                    });
                    await render();
                } catch (error) {
                    showError(error);
                    await render();
                }
            });
        });

        table.querySelectorAll("[data-proceed-id]").forEach(btn => {
            btn.addEventListener("click", async () => {
                const id = btn.dataset.proceedId;
                try {
                    btn.disabled = true;
                    btn.textContent = "Processing...";
                    await api(`/api/requests/${id}`, {
                        method: "PATCH",
                        body: JSON.stringify({
                            action: "proceed",
                            volunteer_email: session.email
                        })
                    });
                    await render();
                } catch (err) {
                    showError(err);
                    await render();
                }
            });
        });
    }

    if (filter && filter.dataset.rlReady !== "true") {
        filter.dataset.rlReady = "true";
        filter.addEventListener("change", () => render().catch(showError));
    }

    setupIncidentForm(session);
    await Promise.all([
        render(),
        loadIncidents(),
        loadVolunteerDonations(session)
    ]);
}

// ========================================
// ADMIN DASHBOARD
// ========================================
async function setupAdminDashboard(session) {
    const volunteerTable = document.getElementById("volunteerApplicationsTable");
    const requestTable = document.getElementById("adminRequestsTable");
    const donationTable = document.getElementById("adminDonationsTable");

    async function render() {
        const [requestData, volunteerData, donationData] = await Promise.all([
            api("/api/requests").catch(() => []),
            api("/api/volunteers").catch(() => []),
            api("/api/donations").catch(() => [])
        ]);

        const requests = normalizeList(requestData, ["requests", "data", "items"]);
        const volunteers = normalizeList(volunteerData, ["volunteers", "data", "items"]);
        const donations = normalizeList(donationData, ["donations", "data", "items"]);

        setText("adminRequestCount", requests.length);
        setText("adminPendingVolunteers", volunteers.filter(item => (item.status || "Pending") === "Pending").length);
        setText("adminOpenRequests", requests.filter(item => item.status !== "Resolved").length);

        if (volunteerTable) {
            volunteerTable.innerHTML = volunteers.length
                ? volunteers.map(item => `
                    <tr>
                        <td>${escapeHTML(item.name)}</td>
                        <td>${escapeHTML(item.email)}</td>
                        <td>${escapeHTML(item.phone)}</td>
                        <td>${escapeHTML(item.skill)}</td>
                        <td>${statusPill(item.status || "Pending")}</td>
                        <td>
                            ${(item.status || "Pending") === "Pending"
                                ? `<button type="button" data-volunteer-id="${escapeHTML(item.id)}" data-action="Approved">Approve</button>
                                   <button type="button" data-volunteer-id="${escapeHTML(item.id)}" data-action="Rejected">Reject</button>`
                                : "Reviewed"}
                        </td>
                    </tr>
                `).join("")
                : '<tr><td colspan="6">No applications yet.</td></tr>';

            volunteerTable.querySelectorAll("[data-action]").forEach(button => {
                button.addEventListener("click", async () => {
                    try {
                        button.disabled = true;
                        await api(`/api/volunteers/${button.dataset.volunteerId}`, {
                            method: "PATCH",
                            body: JSON.stringify({ status: button.dataset.action })
                        });
                        await render();
                    } catch (error) {
                        showError(error);
                        await render();
                    }
                });
            });
        }

        if (requestTable) {
            requestTable.innerHTML = requests.length
                ? requests.map(item => `
                    <tr>
                        <td>#RL-${escapeHTML(item.id)}</td>
                        <td>
                            <div style="font-weight:700; color:#092d46;">${escapeHTML(item.name || "User")}</div>
                            <a href="mailto:${escapeHTML(item.owner || item.email)}" style="font-size:11px; color:#087e78; text-decoration:underline;">${escapeHTML(item.owner || item.email)}</a>
                        </td>
                        <td>${escapeHTML(item.type || item.category)}</td>
                        <td>${formatLocationDisplay(item.location)}</td>
                        <td>${escapeHTML(getDescription(item))}</td>
                        <td>${priorityPill(item.priority)}</td>
                        <td>${statusPill(item.status || "Pending")}</td>
                    </tr>
                `).join("")
                : '<tr><td colspan="7">No requests yet.</td></tr>';
        }

        if (donationTable) {
            donationTable.innerHTML = donations.length
                ? donations.map(item => `
                    <tr>
                        <td>#D-${escapeHTML(item.id)}</td>
                        <td>
                            <div style="font-weight:700; color:#092d46;">${escapeHTML(item.donor_name)}</div>
                            <a href="mailto:${escapeHTML(item.donor_email)}" style="font-size:11px; color:#087e78; text-decoration:underline;">${escapeHTML(item.donor_email)}</a>
                        </td>
                        <td>${escapeHTML(item.item_category)}</td>
                        <td>${formatLocationDisplay(item.location)}</td>
                        <td>${escapeHTML(item.item_details)}</td>
                        <td>${statusPill(item.status || "Available")}</td>
                        <td>${escapeHTML(item.pickup_message || "No pickup scheduled")}</td>
                    </tr>
                `).join("")
                : '<tr><td colspan="7">No donations yet.</td></tr>';
        }
    }

    setupIncidentForm(session);
    await Promise.all([render(), loadIncidents()]);
}

// ========================================
// START APPLICATION
// ========================================
async function init() {
    setupLogin();
    setupVolunteerRegistration();
    setupLogout();

    const page = document.body.dataset.page;
    if (!page) return;

    const normalizedPage = normalizeRole(page);
    if (!normalizedPage) return;

    // user-dashboard runs its own self-contained inline script
    if (normalizedPage === "user") return;

    const session = requireSession(normalizedPage);
    if (!session) return;

    try {
        if (normalizedPage === "volunteer") {
            await setupVolunteerDashboard(session);
        } else if (normalizedPage === "admin") {
            await setupAdminDashboard(session);
        }
    } catch (error) {
        console.error("Dashboard loading failed:", error);
        showError(error);
    }
}

document.addEventListener("DOMContentLoaded", init);